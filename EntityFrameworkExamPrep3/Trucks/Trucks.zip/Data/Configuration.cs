﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-Q7KF8R7\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}