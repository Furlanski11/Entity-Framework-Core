﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-Q7KF8R7\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
