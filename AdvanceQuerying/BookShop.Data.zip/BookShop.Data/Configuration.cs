﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-Q7KF8R7\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
