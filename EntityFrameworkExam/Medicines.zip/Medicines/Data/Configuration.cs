﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-Q7KF8R7\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False";
    }
}
